Ext.define('Logger', {
    singleton: true,
    log: function(msg) {
        console.log(msg);
    }
});