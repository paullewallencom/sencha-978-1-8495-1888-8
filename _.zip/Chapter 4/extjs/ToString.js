Ext.define('ToString', {
	getString: function() {
		return "NAME: " + this.name + "\nADDRESS: " + this.address + "\nAGE: " + this.age;
	}
});