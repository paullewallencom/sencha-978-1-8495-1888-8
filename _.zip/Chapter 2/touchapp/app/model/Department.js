Ext.define('AM.model.Department', {
    extend: 'Ext.data.Model',
    config: {
        fields: ['code', 'name', 'location']
    }
});